This is a decrypter and encrypter
THE 7 OPTION DOES NOT WORK
this is a prototype and changed will somtimes be released also i am not sure when but this will also be released to "codeworldhub.co.uk" ok so we are working on it and hopefully get a .com domain soon but thats it for now
also just download it as zip that is the only way it will work

